# BigDataFinalLab
* Titanic task solution (Kaggle project)<br />
https://www.kaggle.com/c/titanic<br />
* List of participants:

| Person | Role description                    |
| ------------- | ------------------------------ |
| Tsvetkova Alexandra 	| 	Prepared this file and analytics presentation |
| Makarenko Dmitriy 	  |	  Prepared a solution based on a neural network |
| Lyan Artem 		        |	  Prepared a solution based on logistics regression method |
| Ivanushenko Alexandr	|	  Prepared a solution based on decision trees |
| Fedotov Ivan		      |	  Prepared business presentation |
* https://github.com/sash-tsvet/BigDataFinalLab/
